import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle
from matplotlib.widgets import Button
import random
import time
import math  # <--- Added for Sqrt
import bridge  # Member 2's file

# --- Constants ---
COLOR_LEFT = '#1f77b4'   # Blue
COLOR_RIGHT = '#ff7f0e'  # Orange
COLOR_STRIP = '#ffff99'  # Light Yellow
COLOR_STRIP_PTS = 'green'

# --- Global Variables ---
points = []
fig, ax = None, None
algo_generator = None
btn_rand, btn_start, btn_next, btn_graph, btn_reset = None, None, None, None, None

# ==========================================
# PART 0: EUCLIDEAN HELPER (For Strip Width Only)
# ==========================================
def get_visual_euclidean_d(pts):
    """
    Calculates the minimum Euclidean distance for the current points.
    We use this ONLY to draw the strip so it looks 'tighter' and cleaner.
    """
    if len(pts) < 2:
        return float('inf')
    
    min_d = float('inf')
    for i in range(len(pts)):
        for j in range(i + 1, len(pts)):
            # Euclidean Formula: sqrt((x2-x1)^2 + (y2-y1)^2)
            d = math.sqrt((pts[i][0] - pts[j][0])**2 + (pts[i][1] - pts[j][1])**2)
            if d < min_d:
                min_d = d
    return min_d

# ==========================================
# PART 1: ALGORITHM LOGIC
# ==========================================
def algorithm_logic_generator(sorted_points, level=0):
    n = len(sorted_points)
    
    if n <= 3:
        return

    # --- DIVIDE STEP ---
    mid = n // 2
    
    left_max_x = sorted_points[mid-1][0]
    right_min_x = sorted_points[mid][0]
    split_x = (left_max_x + right_min_x) / 2
    
    # 1. VISUALIZE SPLIT
    ax.clear()
    setup_plot_area()
    
    left_pts = sorted_points[:mid]
    left_x = [p[0] for p in left_pts]
    left_y = [p[1] for p in left_pts]
    ax.scatter(left_x, left_y, color=COLOR_LEFT, s=80, label='Left Partition')

    right_pts = sorted_points[mid:]
    right_x = [p[0] for p in right_pts]
    right_y = [p[1] for p in right_pts]
    ax.scatter(right_x, right_y, color=COLOR_RIGHT, s=80, label='Right Partition')

    color = 'black' if level == 0 else 'gray'
    ax.axvline(x=split_x, color=color, linestyle='--', linewidth=2, label='Split Line')
    
    ax.set_title(f"Step: Dividing {n} points at X={split_x:.1f}", color='blue', fontweight='bold')
    ax.legend(loc='upper right')
    plt.draw()
    
    yield 

    yield from algorithm_logic_generator(left_pts, level + 1)
    yield from algorithm_logic_generator(right_pts, level + 1)

    # --- COMBINE STEP (EUCLIDEAN CONVERSION) ---
    
    # 1. Get Euclidean 'd' purely for visualization
    # This makes the strip look "normal" (not massive)
    visual_d = get_visual_euclidean_d(sorted_points)

    # 2. Draw Yellow Strip Region using visual_d
    rect = Rectangle((split_x - visual_d, 0), 2 * visual_d, 100, 
                     facecolor=COLOR_STRIP, alpha=0.5, label=f'Strip (d={visual_d:.2f})')
    ax.add_patch(rect)
    
    # 3. Highlight Points INSIDE the strip
    strip_points_x = []
    strip_points_y = []
    
    for p in sorted_points:
        if abs(p[0] - split_x) < visual_d:
            strip_points_x.append(p[0])
            strip_points_y.append(p[1])
            
    ax.scatter(strip_points_x, strip_points_y, color=COLOR_STRIP_PTS, s=100, edgecolors='black', zorder=5, label='Checked in Strip')

    ax.set_title(f"Step: Checking Strip (Visual Width d={visual_d:.2f})", color='brown', fontweight='bold')
    
    ax.scatter(left_x, left_y, color=COLOR_LEFT, s=60, alpha=0.3)
    ax.scatter(right_x, right_y, color=COLOR_RIGHT, s=60, alpha=0.3)
    
    plt.draw()
    
    yield 

    rect.remove()

# ==========================================
# PART 2: TIME ANALYSIS
# ==========================================
def show_time_analysis(event):
    print("\n[Button Clicked] Time Analysis Started...")
    ax.set_title("Running Benchmark... Please Wait...", color='purple')
    plt.draw()
    plt.pause(0.1)

    input_sizes = [100, 500, 1000, 2000, 3000]
    times_brute = []
    times_optimal = []

    for n in input_sizes:
        data = [(random.uniform(0, 10000), random.uniform(0, 10000)) for _ in range(n)]
        
        start = time.time()
        bridge.run_brute_force_algorithm(data)
        times_brute.append(time.time() - start)

        start = time.time()
        bridge.run_cpp_algorithm(data)
        times_optimal.append(time.time() - start)
        print(f"Tested N={n}")

    fig2 = plt.figure(figsize=(10, 6), num="Time Complexity Analysis")
    ax2 = fig2.add_subplot(111)
    ax2.plot(input_sizes, times_brute, 'r-o', label='Brute Force O(N^2)')
    ax2.plot(input_sizes, times_optimal, 'g-o', label='Divide & Conquer O(N log N)')
    
    ax2.set_title("Performance Comparison (Manhattan Distance)")
    ax2.set_xlabel("Number of Points")
    ax2.set_ylabel("Time (seconds)")
    ax2.legend()
    ax2.grid(True)
    
    ax.set_title("Benchmark Complete! Check new window.", color='green')
    plt.show()

# ==========================================
# PART 3: BUTTON FUNCTIONS
# ==========================================
def start_algorithm_setup(event):
    global algo_generator
    print("[Button Clicked] Start Algo")
    if len(points) < 2:
        ax.set_title("Add points first!", color='red')
        plt.draw()
        return

    sorted_points = sorted(points, key=lambda p: p[0])
    algo_generator = algorithm_logic_generator(sorted_points)
    
    try:
        next(algo_generator)
    except StopIteration:
        finish_algorithm()
    plt.draw()

def next_step(event):
    global algo_generator
    print("[Button Clicked] Next Step")
    if not algo_generator:
        ax.set_title("Click 'Start Algo' first!", color='red')
        plt.draw()
        return
    try:
        next(algo_generator)
    except StopIteration:
        finish_algorithm()

def finish_algorithm():
    global algo_generator
    algo_generator = None
    min_dist = bridge.run_cpp_algorithm(points)
    
    p1, p2 = None, None
    epsilon = 0.000001
    found = False
    
    for i in range(len(points)):
        for j in range(i + 1, len(points)):
            d = abs(points[i][0] - points[j][0]) + abs(points[i][1] - points[j][1])
            if abs(d - min_dist) < epsilon:
                p1, p2 = points[i], points[j]
                found = True
                break
        if found: break
    
    update_plot()
    
    if p1 and p2:
        corner_x, corner_y = p2[0], p1[1]
        ax.plot([p1[0], corner_x], [p1[1], corner_y], color='red', linewidth=3, linestyle='-')
        ax.plot([corner_x, p2[0]], [corner_y, p2[1]], color='red', linewidth=3, linestyle='-', label='Manhattan Path')
        ax.scatter([p1[0], p2[0]], [p1[1], p2[1]], color='red', s=150, zorder=10)
        ax.set_title(f"FINAL RESULT: {min_dist:.2f} (Manhattan Path)", color='red', fontweight='bold')
        ax.legend()
    plt.draw()

def generate_random_points(event):
    global points, algo_generator
    algo_generator = None
    points.extend([(random.uniform(5, 95), random.uniform(5, 95)) for _ in range(5)])
    update_plot()

def add_point_on_click(event):
    if event.inaxes == ax and algo_generator is None:
        points.append((event.xdata, event.ydata))
        update_plot()

def reset(event):
    global points, algo_generator
    points = []
    algo_generator = None
    ax.cla()
    setup_plot_area()
    plt.draw()

def update_plot():
    ax.clear()
    setup_plot_area()
    if points:
        xs, ys = zip(*points)
        ax.scatter(xs, ys, color='blue', s=60, edgecolors='white')
    plt.draw()

def setup_plot_area():
    ax.set_xlim(0, 100)
    ax.set_ylim(0, 100)
    ax.set_title("Manhattan Closest Pair Visualizer", color='black')
    ax.set_xlabel("X Coordinate")
    ax.set_ylabel("Y Coordinate")
    ax.grid(True, linestyle=':', alpha=0.3)

# ==========================================
# PART 4: MAIN APP
# ==========================================
def start_app():
    global fig, ax, btn_rand, btn_start, btn_next, btn_graph, btn_reset
    
    fig, ax = plt.subplots(figsize=(12, 8))
    plt.subplots_adjust(bottom=0.2)
    setup_plot_area()

    ax_rand = plt.axes([0.05, 0.05, 0.12, 0.075])
    btn_rand = Button(ax_rand, 'Add Random')
    btn_rand.on_clicked(generate_random_points)
    
    ax_start = plt.axes([0.20, 0.05, 0.12, 0.075])
    btn_start = Button(ax_start, 'Start Algo', color='orange')
    btn_start.on_clicked(start_algorithm_setup)

    ax_next = plt.axes([0.35, 0.05, 0.15, 0.075])
    btn_next = Button(ax_next, 'Next Step >>', color='lightgreen')
    btn_next.on_clicked(next_step)

    ax_graph = plt.axes([0.55, 0.05, 0.20, 0.075])
    btn_graph = Button(ax_graph, 'Time Analysis', color='#D8BFD8')
    btn_graph.on_clicked(show_time_analysis)

    ax_reset = plt.axes([0.80, 0.05, 0.1, 0.075])
    btn_reset = Button(ax_reset, 'Reset', color='salmon')
    btn_reset.on_clicked(reset)

    fig.canvas.mpl_connect('button_press_event', add_point_on_click)
    print("Visualizer Loaded: Euclidean Strip Logic.")
    plt.show()

if __name__ == "__main__":
    start_app()
